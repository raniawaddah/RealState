from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class Property(models.Model):
    _name = 'property'


    name = fields.Char(required=1, default='name', size=10)
    description = fields.Text()
    postcode = fields.Char(required=1)
    date_availability = fields.Date()
    expected_price = fields.Float()
    selling_price = fields.Float()
    diff = fields.Float(Compute='_compute_diff', readonly=0,)
    bedrooms = fields.Integer()
    living_area = fields.Integer()
    facades = fields.Integer()
    garage = fields.Boolean()
    garden = fields.Boolean()
    garden_area = fields.Integer()
    garden_orientation = fields.Selection([
        ('north', 'North'),
        ('south', 'South'),
        ('east', 'East'),
        ('west', 'West'),
    ], default='south')

    owner_id = fields.Many2one('owner', )
    tag_ids = fields.Many2many('tag', )

    state = fields.Selection([
        ('draft', 'Draft'),
        ('pending', 'Pending'),
        ('sold', 'Sold'),

    ], default='draft', )


    _sql_constraints = [
        ('unique_name', 'unique("name")', 'This name is exist!!')
    ]

    @api.onchange('expected_price')
    def _onchange_expected_price(self):
        for rec in self:
            print("inside _onchange_expected_price method ")
            return {
                'warning': {'title': "Warning", 'message': "Negative Value", 'type': 'notification'},
            }


    @api.depends('expected_price', 'selling_price', 'diff')
    def _compute_diff(self):
        for rec in self:
            print("inside _compute_diff method ")
            rec.diff = rec.expected_price - rec.selling_price

    @api.constrains('bedrooms')
    def _check_bedrooms_greater_zero(self):
        for rec in self:
            if rec.bedrooms == 0:
                raise ValidationError('Please add valid number of bedrooms!')


    def action_draft(self):
        for rec in self:
            rec.state = 'draft'

    def action_pending(self):
        for rec in self:
            rec.state = 'pending'

    def action_sold(self):
        for rec in self:
            rec.state = 'sold'


    # @api.model_create_multi
    # def create(self, vals):
    #     res = super(Property, self).create(vals)
    #     print("inside create method")
    #     return res
    #
    # @api.model
    #
    # def _search(self, args, offset=0, limit=None, order=None, count=False, access_rights_uid=None):
    #
    #     res = super(Property, self)._search(args, offset=0, limit=None, order=None, count=False, access_rights_uid=None)
    #     print("inside search method")
    #     return res
    #
    #
    # def write(self, vals):
    #     res = super(Property, self).write(vals)
    #     print("inside write method")
    #     return res
    #
    # def unlink(self):
    #     res = super(Property, self).unlink()
    #     print("inside unlink method")
    #     return res


